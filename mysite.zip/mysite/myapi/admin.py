from django.contrib import admin
from .models import employ
admin.site.register(employ)